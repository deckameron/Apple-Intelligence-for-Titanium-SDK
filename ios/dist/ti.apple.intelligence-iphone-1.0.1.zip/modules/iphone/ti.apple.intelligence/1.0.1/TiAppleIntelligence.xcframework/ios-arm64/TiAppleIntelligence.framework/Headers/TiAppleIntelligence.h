//
//  TiAppleIntelligence.h
//  Ti.Apple.Intelligence
//
//  Created by Your Name
//  Copyright (c) 2025 Your Company. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TiAppleIntelligence.
FOUNDATION_EXPORT double TiAppleIntelligenceVersionNumber;

//! Project version string for TiAppleIntelligence.
FOUNDATION_EXPORT const unsigned char TiAppleIntelligenceVersionString[];

#import "TiAppleIntelligenceModuleAssets.h"
